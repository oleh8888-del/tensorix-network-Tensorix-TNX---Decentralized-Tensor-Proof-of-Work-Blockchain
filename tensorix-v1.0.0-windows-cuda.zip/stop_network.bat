@echo off
title Stop Tensorix Network
echo Stopping Tensorix Node and Stratum Pool...
powershell -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'start_node|start_stratum|start_miner' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }; Write-Host 'All Tensorix services stopped.' -ForegroundColor Green"
pause

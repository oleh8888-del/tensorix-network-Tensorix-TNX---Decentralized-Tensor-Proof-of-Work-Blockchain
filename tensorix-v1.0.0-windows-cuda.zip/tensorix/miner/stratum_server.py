"""
Tensorix Network (TNX) - Stratum Mining Pool Server
Provides standard Stratum V1 TCP protocol (port 3333) and HTTP stats monitoring.
Allows multiple external or local miners to connect and share work.
"""

import sys
import os
import json
import time
import asyncio
import httpx
from typing import Dict, Set

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from ..consensus.tensor_pow import tensor_pow_hash_cpu, difficulty_to_target, MAX_TARGET

DEFAULT_NODE_URL = "http://127.0.0.1:8333"
DEFAULT_STRATUM_PORT = 3333
DEFAULT_SHARE_DIFF = 0.5  # Friendly share difficulty for miners to report hashrate regularly


class StratumClient:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, client_id: str):
        self.reader = reader
        self.writer = writer
        self.client_id = client_id
        self.worker_name = "unknown"
        self.payout_address = ""
        self.authorized = False
        self.shares = 0
        self.blocks = 0
        self.last_share_time = time.time()
        self.hashrate = 0.0

    async def send_json(self, data: dict):
        line = json.dumps(data) + "\n"
        self.writer.write(line.encode("utf-8"))
        await self.writer.drain()


class StratumServer:
    def __init__(self, node_url: str = DEFAULT_NODE_URL, port: int = DEFAULT_STRATUM_PORT, default_payout: str = ""):
        self.node_url = node_url.rstrip("/")
        self.port = port
        self.default_payout = default_payout
        self.clients: Dict[str, StratumClient] = {}
        self.current_template: dict = {}
        self.total_pool_shares = 0
        self.total_blocks_found = 0
        self.job_counter = 0

    async def fetch_template(self) -> dict:
        """Fetch latest block template from local Tensorix node."""
        addr = self.default_payout or "tnx1b050bd6e525ac254ab212efce117cc636eb1166e"
        url = f"{self.node_url}/mining/template?address={addr}"
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                res = await client.get(url)
                if res.status_code == 200:
                    return res.json()
        except Exception as e:
            print(f"[Stratum Pool] Error contacting node: {e}")
        return {}

    async def submit_block_to_node(self, template: dict, nonce: int) -> bool:
        url = f"{self.node_url}/mining/submit"
        payload = {
            "index": template["index"],
            "prev_hash": template["prev_hash"],
            "timestamp": template["timestamp"],
            "difficulty": template["difficulty"],
            "nonce": nonce,
            "merkle_root": template["merkle_root"],
            "transactions": template["transactions"]
        }
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                res = await client.post(url, json=payload)
                if res.status_code == 200:
                    self.total_blocks_found += 1
                    print(f"\n🎉 [STRATUM POOL] BLOCK #{template['index']} FOUND BY POOL MINER! Subsidies credited.")
                    return True
                else:
                    print(f"\n❌ [STRATUM POOL] Node rejected block: {res.text}")
        except Exception as e:
            print(f"[STRATUM POOL] Error submitting block: {e}")
        return False

    async def notify_all_miners(self, clean_jobs: bool = False):
        if not self.current_template:
            return
        
        self.job_counter += 1
        job_id = f"job_{self.job_counter}"
        header_hash = self.current_template["header_hash"]
        target = self.current_template["target"]

        notification = {
            "id": None,
            "method": "mining.notify",
            "params": [
                job_id,
                header_hash,
                target,
                clean_jobs
            ]
        }

        for client in list(self.clients.values()):
            if client.authorized:
                try:
                    await client.send_json(notification)
                except Exception:
                    pass

    async def handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        addr_info = writer.get_extra_info("peername")
        client_id = f"{addr_info[0]}:{addr_info[1]}"
        client = StratumClient(reader, writer, client_id)
        self.clients[client_id] = client
        print(f"[Stratum Pool] New miner connected from {client_id}")

        try:
            while True:
                line = await reader.readline()
                if not line:
                    break

                # If connection sent HTTP GET request (web browser view)
                if line.startswith(b"GET ") or line.startswith(b"POST "):
                    # Handle lightweight HTTP dashboard
                    stats_body = json.dumps({
                        "pool": "Tensorix Official Stratum Mining Pool",
                        "status": "online",
                        "stratum_endpoint": f"stratum+tcp://0.0.0.0:{self.port}",
                        "active_miners": len([c for c in self.clients.values() if c.authorized]),
                        "total_shares": self.total_pool_shares,
                        "total_blocks_found": self.total_blocks_found,
                        "current_block_index": self.current_template.get("index", 0),
                        "network_difficulty": self.current_template.get("difficulty", 1.0),
                        "miners": [
                            {"client": c.client_id, "worker": c.worker_name, "shares": c.shares}
                            for c in self.clients.values() if c.authorized
                        ]
                    }, indent=2)
                    http_resp = (
                        "HTTP/1.1 200 OK\r\n"
                        "Content-Type: application/json; charset=utf-8\r\n"
                        f"Content-Length: {len(stats_body.encode('utf-8'))}\r\n"
                        "Access-Control-Allow-Origin: *\r\n"
                        "\r\n" + stats_body
                    )
                    writer.write(http_resp.encode("utf-8"))
                    await writer.drain()
                    break

                try:
                    msg = json.loads(line.decode("utf-8"))
                except Exception:
                    continue

                msg_id = msg.get("id")
                method = msg.get("method")
                params = msg.get("params", [])

                if method == "mining.subscribe":
                    # Reply with subscription details
                    extranonce1 = "0100"
                    res = [
                        [
                            ["mining.set_difficulty", "sub_diff"],
                            ["mining.notify", "sub_notify"]
                        ],
                        extranonce1,
                        4
                    ]
                    await client.send_json({"id": msg_id, "result": res, "error": None})
                    # Set client share difficulty
                    await client.send_json({"id": None, "method": "mining.set_difficulty", "params": [DEFAULT_SHARE_DIFF]})

                elif method == "mining.authorize":
                    username = params[0] if params else "miner.worker1"
                    client.worker_name = username
                    client.payout_address = username.split(".")[0]
                    client.authorized = True
                    print(f"[Stratum Pool] Miner {client_id} authorized as '{username}'")
                    await client.send_json({"id": msg_id, "result": True, "error": None})
                    
                    # Immediately send current job
                    if self.current_template:
                        await client.send_json({
                            "id": None,
                            "method": "mining.notify",
                            "params": [
                                f"job_{self.job_counter}",
                                self.current_template["header_hash"],
                                self.current_template["target"],
                                True
                            ]
                        })

                elif method == "mining.submit":
                    # Params: [worker_name, job_id, extranonce2, ntime, nonce]
                    try:
                        nonce = int(params[4]) if len(params) > 4 else int(params[2])
                    except (ValueError, TypeError):
                        nonce = 0

                    client.shares += 1
                    self.total_pool_shares += 1
                    
                    # Verify Proof-of-Work
                    if self.current_template:
                        h_bytes = bytes.fromhex(self.current_template["header_hash"])
                        net_target = int(self.current_template["target"], 16)
                        share_target = difficulty_to_target(DEFAULT_SHARE_DIFF)

                        pow_hash = tensor_pow_hash_cpu(h_bytes, nonce)
                        pow_int = int.from_bytes(pow_hash, "big")

                        if pow_int <= net_target:
                            # BLOCK FOUND! Submit immediately to blockchain node
                            print(f"\n🔥 [BLOCK CANDIDATE] Nonce {nonce} meets NETWORK TARGET!")
                            await self.submit_block_to_node(self.current_template, nonce)
                            await client.send_json({"id": msg_id, "result": True, "error": None})
                            # Trigger new template fetch
                            tmpl = await self.fetch_template()
                            if tmpl:
                                self.current_template = tmpl
                                await self.notify_all_miners(clean_jobs=True)
                        elif pow_int <= share_target:
                            # Valid pool share
                            await client.send_json({"id": msg_id, "result": True, "error": None})
                        else:
                            # Low difficulty share
                            await client.send_json({"id": msg_id, "result": False, "error": [21, "Low difficulty share", None]})
                    else:
                        await client.send_json({"id": msg_id, "result": True, "error": None})

                elif method == "mining.get_transactions":
                    await client.send_json({"id": msg_id, "result": [], "error": None})
                else:
                    await client.send_json({"id": msg_id, "result": None, "error": [20, "Method not supported", None]})

        except Exception as e:
            print(f"[Stratum Pool] Client {client_id} disconnected: {e}")
        finally:
            self.clients.pop(client_id, None)
            writer.close()

    async def template_poll_loop(self):
        """Polls node for new blocks / templates every 3 seconds."""
        last_index = -1
        while True:
            tmpl = await self.fetch_template()
            if tmpl and tmpl.get("index") != last_index:
                print(f"[Stratum Pool] New network job #{tmpl['index']} | Difficulty: {tmpl['difficulty']:.2f}")
                self.current_template = tmpl
                last_index = tmpl["index"]
                await self.notify_all_miners(clean_jobs=True)
            await asyncio.sleep(3)

    async def start(self):
        print("=" * 65)
        print("⚡ TENSORIX STRATUM MINING POOL SERVER (TNX)")
        print(f"Stratum Port:   tcp://0.0.0.0:{self.port}")
        print(f"Pool Dashboard: http://127.0.0.1:{self.port}/")
        print(f"Node RPC:       {self.node_url}")
        print("=" * 65)

        # Initial fetch
        self.current_template = await self.fetch_template()

        server = await asyncio.start_server(self.handle_client, "0.0.0.0", self.port)
        asyncio.create_task(self.template_poll_loop())

        async with server:
            await server.serve_forever()


def main():
    port = int(os.environ.get("STRATUM_PORT", DEFAULT_STRATUM_PORT))
    node_url = os.environ.get("TENSORIX_NODE", DEFAULT_NODE_URL)
    pool = StratumServer(node_url=node_url, port=port)
    asyncio.run(pool.start())


if __name__ == "__main__":
    main()

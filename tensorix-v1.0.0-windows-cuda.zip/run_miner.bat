@echo off
title Tensorix Miner GPU 0 (RTX 5060 Ti)
echo ===================================================
echo Starting Tensorix GPU Tensor-Core Miner on GPU 0...
echo ===================================================
set PYTHONIOENCODING=utf-8
python start_miner.py 0 http://127.0.0.1:8333
pause

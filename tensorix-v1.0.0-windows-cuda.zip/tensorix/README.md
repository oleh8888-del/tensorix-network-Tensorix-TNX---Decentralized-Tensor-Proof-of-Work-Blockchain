# 🚀 Tensorix Network (TNX)

**Tensorix (TNX)** — це децентралізований Proof-of-Work блокчейн, створений спеціально під обчислення на тензорних ядрах графічних процесорів NVIDIA (RTX 20xx / 30xx / 40xx / 50xx).

---

## 💎 Токеноміка та Характеристики

| Параметр | Значення |
| :--- | :--- |
| **Назва монети** | **Tensorix** |
| **Тікер** | **TNX** |
| **Формат адрес** | `tnx1...` (Ed25519 криптографія) |
| **Алгоритм консенсусу** | **TensorHash (PoTW - Proof of Tensor Work)** |
| **Цільове залізо** | NVIDIA Tensor Cores (INT8/INT32 GEMM матричне множення) |
| **Час блоку** | 60 секунд |
| **Початкова винагорода** | 10 TNX за блок |
| **Халвінг (зменшення вдвічі)** | Кожні 1 051 200 блоків (~2 роки) |
| **Максимальна емісія (Max Supply)** | 21 000 000 TNX |
| **Перерахунок складності** | LWMA (Linear Weighted Moving Average) плавний кожен блок |

---

## 🏗️ Архітектура Системи «Під Ключ»

* `tensorix/consensus/crypto.py` — Ed25519 підписи транзакцій, Blake3/SHA256 криптографічні хеші.
* `tensorix/consensus/tensor_pow.py` — Алгоритм TensorHash (детерміноване множення цілочисельних матриць на тензорних ядрах GPU).
* `tensorix/consensus/difficulty.py` — Алгоритм плавного регулювання складності LWMA.
* `tensorix/blockchain/transaction.py` — Модель транзакцій із захистом від повторного відтворення (nonces) та Coinbase.
* `tensorix/blockchain/block.py` — Структура блоку, дерево Меркла, перевірка Proof-of-Work.
* `tensorix/blockchain/chain.py` — Двигун блокчейну, стан рахунків (Ledger), Mempool, збереження на диск.
* `tensorix/node/server.py` — RPC/REST сервер ноди (FastAPI / Uvicorn).
* `tensorix/miner/tensor_miner.py` — Апаратний майнер під NVIDIA Tensor Cores (CuPy / cuBLAS).
* `tensorix/wallet/wallet_cli.py` — Повнофункціональний CLI-гаманець.

---

## 🚀 Як користуватися (Швидкий старт)

### 1. Запуск Ноди мережі:
Запустіть файл `run_node.bat` або виконайте в терміналі:
```powershell
python start_node.py
```
* Нода запуститься за адресою: `http://127.0.0.1:8333`
* Інтерактивна документація API Swagger: `http://127.0.0.1:8333/docs`

### 2. Запуск майнінгу на відеокартах:
* Для майнінгу на **GPU 0 (RTX 5060 Ti)**:
  ```powershell
  .\run_miner.bat
  ```
* Для майнінгу на **GPU 1 (RTX 5060)**:
  ```powershell
  .\run_miner_gpu1.bat
  ```

### 3. Робота з гаманцем:
* Перевірити баланс:
  ```powershell
  .\wallet.bat balance
  ```
* Дізнатися свою адресу:
  ```powershell
  .\wallet.bat address
  ```
* Надіслати монети:
  ```powershell
  .\wallet.bat send --to tnx1... --amount 5.0
  ```
* Створити новий гаманець:
  ```powershell
  python -m tensorix.wallet.wallet_cli create --file new_wallet.json
  ```

---

## ⚡ Чому TensorHash захищений від ASIC?
На відміну від звичайних алгоритмів (SHA-256, Scrypt), які вимагають простих логічних операцій, TensorHash навантажує масивні тензорні матричні множники (GEMM). Створення окремих ASIC під такий тип матричних обчислень не має сенсу, оскільки відеокарти серій RTX 20/30/40/50 вже мають найкращу енергоефективність тензорних ядер у світі.

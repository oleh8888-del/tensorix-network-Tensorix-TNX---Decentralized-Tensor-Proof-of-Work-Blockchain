@echo off
title Tensorix Network Launcher
set PYTHONIOENCODING=utf-8
powershell -ExecutionPolicy Bypass -File "%~dp0start_network.ps1"
pause

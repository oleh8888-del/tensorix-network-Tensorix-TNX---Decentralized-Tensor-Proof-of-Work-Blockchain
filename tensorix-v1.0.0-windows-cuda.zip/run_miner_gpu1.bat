@echo off
title Tensorix Miner GPU 1 (RTX 5060)
echo ===================================================
echo Starting Tensorix GPU Tensor-Core Miner on GPU 1...
echo ===================================================
set PYTHONIOENCODING=utf-8
python start_miner.py 1 http://127.0.0.1:8333
pause

# Tensorix Network (TNX) Whitepaper
**A Decentralized Tensor-Core Proof-of-Work Blockchain**

*Version 1.0.0 — October 2026*

---

## Abstract
Tensorix (TNX) is a next-generation Layer-1 Proof-of-Work cryptocurrency engineered specifically for hardware-accelerated matrix multiplication on Tensor Processing Cores (NVIDIA Turing, Ampere, Ada Lovelace, and Blackwell architectures). By anchoring the cryptographic consensus to General Matrix Multiply (GEMM) in deterministic integer arithmetic (INT8/INT32), Tensorix creates a robust ASIC-resistant computing ecosystem that leverages commodity consumer AI hardware while preventing centralization from specialized ASIC manufacturers.

---

## 1. Introduction & Motivation
Traditional Proof-of-Work cryptocurrencies rely on memory-hard algorithms (Ethash, KawPow) or simple bitwise integer permutations (SHA-256, Blake2b). These algorithms either succumbed to centralized ASIC dominance or underutilize the massive compute silicon present in modern GPUs.

Since 2018, modern GPUs have dedicated the majority of their die area to Tensor Cores—specialized matrix multiply-accumulate (MMA) processing units capable of hundreds of teraflops. Tensorix utilizes these tensor units directly as the cryptographic work-verification function, turning everyday AI GPUs into secure blockchain validators.

---

## 2. Consensus Mechanism: TensorHash (PoTW)
TensorHash utilizes a multi-round integer matrix multiply-accumulate process:
1. **Seed Generation:** A 32-byte seed is derived from the block header and miner nonce using cryptographic double-hashing:
   $$\text{Seed} = H(\text{Header} \parallel \text{Nonce})$$
2. **Deterministic Matrix Expansion:** The seed initializes pseudo-random generation of two $64 \times 64$ signed 8-bit integer matrices $A$ and $B$:
   $$A, B \in \mathbb{Z}^{64 \times 64}, \quad -128 \le A_{i,j}, B_{i,j} \le 127$$
3. **Hardware Tensor Core GEMM:** Matrices are multiplied using hardware INT8 MMA:
   $$C = A \times B, \quad C_{i,j} = \sum_{k=1}^{64} A_{i,k} \cdot B_{k,j}$$
4. **Non-linear Permutation & Round 2:** The result matrix $C$ is folded and transformed to seed a second tensor pass, preventing algorithmic shortcuts.
5. **Target Evaluation:** The final matrix digest is mapped to a 256-bit integer and verified against the dynamic network target:
   $$\text{Digest}(C) \le \text{Target}$$

### Mathematical Determinism
To prevent chain forks caused by floating-point rounding discrepancies across different GPU architectures, TensorHash exclusively employs **strict integer arithmetic (INT8 inputs, INT32 accumulation)**.

---

## 3. Network Parameters & Tokenomics

* **Ticker:** TNX
* **Max Supply:** 21,000,000 TNX
* **Block Target Time:** 60 seconds
* **Initial Block Reward:** 10 TNX
* **Halving Interval:** 1,051,200 blocks (~2 years)
* **Difficulty Retargeting:** LWMA (Linear Weighted Moving Average) computed on every block across a 30-block window.
* **Cryptography:** Ed25519 for transaction signatures, Blake3/SHA-256 for block hashing.
* **Network Default Ports:**
  * Node RPC / P2P: `8333`
  * Stratum Mining Pool: `3333`

---

## 4. Open-Source Ecosystem
Tensorix is fully open-source under the MIT license, featuring a native Python/C++/CUDA node daemon, a built-in Stratum mining pool server, a high-throughput GPU Tensor Core miner, and a CLI wallet.

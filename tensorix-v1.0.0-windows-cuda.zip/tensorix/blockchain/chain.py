"""
Tensorix Network (TNX) - Blockchain Engine & State Machine
Handles ledger state, mempool, validation, block persistence, and block templates.
"""

import os
import json
import time
from typing import List, Dict, Optional
from .block import Block
from .transaction import Transaction, COIN
from ..consensus.difficulty import calculate_next_difficulty, MIN_DIFFICULTY
from ..consensus.crypto import hash256_hex

# Emission parameters
INITIAL_REWARD = 10 * COIN       # 10 TNX
HALVING_INTERVAL = 1_051_200     # Halving every ~2 years (at 60s per block)
MAX_SUPPLY = 21_000_000 * COIN   # 21M TNX


class Blockchain:
    def __init__(self, data_dir: str = "tensorix_data"):
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        self.chain_file = os.path.join(self.data_dir, "blockchain.json")
        
        self.chain: List[Block] = []
        self.balances: Dict[str, int] = {}
        self.account_nonces: Dict[str, int] = {}
        self.mempool: Dict[str, Transaction] = {}
        
        self.load_or_initialize()

    def get_block_reward(self, height: int) -> int:
        """Calculate block subsidy with halving."""
        halvings = height // HALVING_INTERVAL
        if halvings >= 64:
            return 0
        reward = INITIAL_REWARD >> halvings
        return reward

    def get_latest_block(self) -> Block:
        return self.chain[-1]

    def get_balance(self, address: str) -> int:
        return self.balances.get(address, 0)

    def get_account_nonce(self, address: str) -> int:
        return self.account_nonces.get(address, 0)

    def load_or_initialize(self):
        """Load blockchain from disk if exists, otherwise wait for genesis block."""
        if os.path.exists(self.chain_file):
            try:
                with open(self.chain_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.chain = [Block.from_dict(b) for b in data]
                    self.rebuild_state()
                    print(f"[Tensorix Node] Loaded {len(self.chain)} blocks from disk.")
                    return
            except Exception as e:
                print(f"[Tensorix Node] Error loading chain, initializing fresh: {e}")
        self.chain = []
        self.balances = {}
        self.account_nonces = {}

    def rebuild_state(self):
        """Recompute balances and nonces from genesis to top block."""
        self.balances.clear()
        self.account_nonces.clear()
        for block in self.chain:
            self.apply_block_to_state(block)

    def apply_block_to_state(self, block: Block):
        """Update account balances and transaction nonces."""
        for tx in block.transactions:
            if tx.is_coinbase():
                self.balances[tx.recipient] = self.balances.get(tx.recipient, 0) + tx.amount
            else:
                total_deduction = tx.amount + tx.fee
                self.balances[tx.sender] = self.balances.get(tx.sender, 0) - total_deduction
                self.balances[tx.recipient] = self.balances.get(tx.recipient, 0) + tx.amount
                self.account_nonces[tx.sender] = tx.nonce + 1

    def save_chain(self):
        """Persist blockchain to disk."""
        with open(self.chain_file, "w", encoding="utf-8") as f:
            json.dump([b.to_dict() for b in self.chain], f, indent=2)

    def add_transaction(self, tx: Transaction) -> tuple[bool, str]:
        """Validate and insert transaction into the local mempool."""
        if not tx.is_valid():
            return False, "Invalid signature or transaction format."

        # Balance check (including pending transactions in mempool)
        current_balance = self.get_balance(tx.sender)
        required = tx.amount + tx.fee
        
        # Deduct any pending mempool transactions from this sender
        for mem_tx in self.mempool.values():
            if mem_tx.sender == tx.sender:
                required += mem_tx.amount + mem_tx.fee

        if current_balance < required:
            return False, f"Insufficient balance: have {current_balance}, need {required}."

        expected_nonce = self.get_account_nonce(tx.sender)
        # Verify nonce sequence
        if tx.nonce < expected_nonce:
            return False, f"Invalid nonce: expected >= {expected_nonce}, got {tx.nonce}."

        self.mempool[tx.txid] = tx
        return True, "Transaction accepted into mempool."

    def get_next_difficulty(self) -> float:
        """Calculate next difficulty based on chain history."""
        if len(self.chain) < 2:
            return MIN_DIFFICULTY
        history = [{"timestamp": b.timestamp, "difficulty": b.difficulty} for b in self.chain]
        return calculate_next_difficulty(history)

    def get_block_template(self, miner_address: str) -> dict:
        """Create a candidate block template for miners."""
        latest = self.get_latest_block()
        next_index = latest.index + 1
        next_diff = self.get_next_difficulty()
        
        # Collect candidate transactions from mempool
        candidate_txs: List[Transaction] = []
        total_fees = 0
        for tx in list(self.mempool.values())[:500]:  # up to 500 txs per block
            candidate_txs.append(tx)
            total_fees += tx.fee

        # Coinbase transaction: block subsidy + collected fees
        reward = self.get_block_reward(next_index) + total_fees
        coinbase_tx = Transaction.create_coinbase(miner_address, reward, next_index)
        
        all_txs = [coinbase_tx] + candidate_txs
        tx_hashes = [tx.txid for tx in all_txs]
        
        from .block import calculate_merkle_root
        merkle_root = calculate_merkle_root(tx_hashes)
        now_ts = int(time.time())

        # Construct template block
        template_block = Block(
            index=next_index,
            prev_hash=latest.hash,
            timestamp=now_ts,
            difficulty=next_diff,
            nonce=0,
            transactions=all_txs,
            merkle_root=merkle_root
        )

        header_bytes = template_block.header_bytes()
        from ..consensus.tensor_pow import difficulty_to_target

        return {
            "index": next_index,
            "prev_hash": latest.hash,
            "header_hash": header_bytes.hex(),
            "merkle_root": merkle_root,
            "timestamp": now_ts,
            "difficulty": next_diff,
            "target": hex(difficulty_to_target(next_diff)),
            "reward_tnx": reward / COIN,
            "tx_count": len(all_txs),
            "transactions": [tx.to_dict() for tx in all_txs]
        }

    def submit_block(self, block: Block) -> tuple[bool, str]:
        """Validate and append new mined block to the blockchain."""
        if not self.chain:
            # First block must be genesis
            if block.index != 0:
                return False, "First block must have index 0 (Genesis)."
            if not block.verify_pow():
                return False, "Genesis block PoW verification failed."
            self.chain.append(block)
            self.apply_block_to_state(block)
            self.save_chain()
            return True, "Genesis block accepted."

        latest = self.get_latest_block()
        if block.index != latest.index + 1:
            return False, f"Invalid block index: expected {latest.index + 1}, got {block.index}."

        if block.prev_hash != latest.hash:
            return False, f"Invalid prev_hash: expected {latest.hash}, got {block.prev_hash}."

        if block.timestamp <= latest.timestamp:
            return False, "Block timestamp must be greater than previous block."

        if block.timestamp > time.time() + 7200:
            return False, "Block timestamp is too far in the future."

        # Verify Proof of Work
        if not block.verify_pow():
            return False, "Tensor-PoW verification failed: hash does not satisfy target difficulty."

        # Verify Merkle root
        expected_merkle = block.compute_merkle_root()
        if block.merkle_root != expected_merkle:
            return False, f"Merkle root mismatch: expected {expected_merkle}, got {block.merkle_root}."

        # Verify transactions
        if not block.transactions:
            return False, "Block has no transactions."

        coinbase = block.transactions[0]
        if not coinbase.is_coinbase():
            return False, "First transaction in block must be Coinbase."

        # Compute fee sum from regular transactions
        fee_sum = 0
        for tx in block.transactions[1:]:
            if tx.is_coinbase():
                return False, "Only first transaction can be Coinbase."
            if not tx.is_valid():
                return False, f"Invalid transaction signature for tx {tx.txid}."
            fee_sum += tx.fee

        max_allowed_reward = self.get_block_reward(block.index) + fee_sum
        if coinbase.amount > max_allowed_reward:
            return False, f"Coinbase reward too high: claimed {coinbase.amount}, max {max_allowed_reward}."

        # Apply block to state and remove confirmed transactions from mempool
        self.apply_block_to_state(block)
        for tx in block.transactions[1:]:
            self.mempool.pop(tx.txid, None)

        self.chain.append(block)
        self.save_chain()
        print(f"[Tensorix Node] Accepted block #{block.index} [Diff: {block.difficulty:.2f}] Hash: {block.hash[:16]}...")
        return True, f"Block #{block.index} accepted successfully."

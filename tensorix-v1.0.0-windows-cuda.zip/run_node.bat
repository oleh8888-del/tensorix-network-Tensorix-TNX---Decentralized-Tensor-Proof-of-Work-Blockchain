@echo off
title Tensorix Node Daemon (TNX)
echo ===================================================
echo Starting Tensorix (TNX) Core Node RPC Daemon...
echo ===================================================
set PYTHONIOENCODING=utf-8
python start_node.py
pause

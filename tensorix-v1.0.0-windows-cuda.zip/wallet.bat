@echo off
set PYTHONIOENCODING=utf-8
python -m tensorix.wallet.wallet_cli --file founder_wallet.json %*

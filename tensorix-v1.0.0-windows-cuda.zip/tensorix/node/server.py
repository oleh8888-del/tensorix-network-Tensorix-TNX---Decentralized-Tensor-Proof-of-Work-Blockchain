"""
Tensorix Network (TNX) - Node RPC Daemon & REST API
Provides full REST/RPC endpoints for miners, wallets, and P2P peer nodes.
"""

import os
import uvicorn
from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Optional, List
from ..blockchain.chain import Blockchain, COIN
from ..blockchain.block import Block
from ..blockchain.transaction import Transaction
from ..consensus.crypto import pub_to_address

app = FastAPI(title="Tensorix Node RPC & Explorer", version="1.0.0")
blockchain: Optional[Blockchain] = None
peers: set = set()


class SendTxRequest(BaseModel):
    sender: str
    recipient: str
    amount: int
    fee: int = 10_000
    nonce: int
    public_key: str
    signature: str


class BlockSubmitRequest(BaseModel):
    index: int
    prev_hash: str
    timestamp: int
    difficulty: float
    nonce: int
    merkle_root: str
    transactions: List[dict]


@app.on_event("startup")
def startup_event():
    global blockchain
    data_dir = os.environ.get("TENSORIX_DATA_DIR", "tensorix_data")
    blockchain = Blockchain(data_dir=data_dir)


@app.get("/", response_class=HTMLResponse)
def root_dashboard():
    height = blockchain.get_latest_block().index if blockchain.chain else 0
    diff = blockchain.get_latest_block().difficulty if blockchain.chain else 1.0
    latest_hash = blockchain.get_latest_block().hash if blockchain.chain else "None"
    supply = (sum(b.transactions[0].amount for b in blockchain.chain) / COIN) if blockchain.chain else 0.0

    recent_blocks = list(reversed(blockchain.chain[-10:])) if blockchain.chain else []
    rows_html = ""
    for b in recent_blocks:
        rows_html += f"""
        <tr style="border-bottom: 1px solid #222;">
            <td style="padding: 12px; color: #58a6ff; font-weight: bold;">#{b.index}</td>
            <td style="padding: 12px; font-family: monospace; color: #7ee787;">{b.hash[:20]}...</td>
            <td style="padding: 12px; color: #c9d1d9;">{b.difficulty:.2f}</td>
            <td style="padding: 12px; color: #d2a8ff;">{b.nonce}</td>
            <td style="padding: 12px; color: #8b949e;">{len(b.transactions)} txs</td>
            <td style="padding: 12px; color: #f0883e;">{b.transactions[0].amount / COIN:.2f} TNX</td>
        </tr>
        """

    html = f"""
    <!DOCTYPE html>
    <html lang="uk">
    <head>
        <meta charset="UTF-8">
        <title>Tensorix (TNX) - Live Network Explorer</title>
        <meta http-equiv="refresh" content="5">
        <style>
            body {{ background-color: #0d1117; color: #c9d1d9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; padding: 24px; }}
            .container {{ max-width: 1100px; margin: 0 auto; }}
            .header {{ display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #30363d; padding-bottom: 16px; margin-bottom: 24px; }}
            .logo {{ font-size: 26px; font-weight: bold; color: #58a6ff; letter-spacing: 1px; }}
            .status-badge {{ background: #238636; color: white; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: bold; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 30px; }}
            .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 18px; }}
            .card-title {{ color: #8b949e; font-size: 12px; text-transform: uppercase; font-weight: bold; margin-bottom: 6px; }}
            .card-value {{ font-size: 24px; font-weight: bold; color: #f0f6fc; }}
            .card-sub {{ font-size: 11px; color: #7ee787; margin-top: 4px; }}
            .table-card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 20px; overflow-x: auto; }}
            .code-box {{ background: #0b0e14; border: 1px solid #21262d; padding: 12px 16px; border-radius: 6px; font-family: monospace; color: #79c0ff; font-size: 13px; margin-top: 8px; }}
            table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }}
            th {{ padding: 10px 12px; color: #8b949e; border-bottom: 1px solid #30363d; font-size: 12px; text-transform: uppercase; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="logo">⚡ TENSORIX NETWORK (TNX)</div>
                <div class="status-badge">● MAINNET ONLINE</div>
            </div>

            <div class="grid">
                <div class="card">
                    <div class="card-title">Висота Блокчейну</div>
                    <div class="card-value">#{height}</div>
                    <div class="card-sub">Оновлення кожні 5 сек</div>
                </div>
                <div class="card">
                    <div class="card-title">Складність LWMA</div>
                    <div class="card-value">{diff:.2f}</div>
                    <div class="card-sub">Tensor-PoW (INT8 GEMM)</div>
                </div>
                <div class="card">
                    <div class="card-title">Здобуто Монет</div>
                    <div class="card-value">{supply:.2f} TNX</div>
                    <div class="card-sub">Макс: 21,000,000 TNX</div>
                </div>
                <div class="card">
                    <div class="card-title">Цільовий Час Блоку</div>
                    <div class="card-value">60 сек</div>
                    <div class="card-sub">Халвінг кожні 2 роки</div>
                </div>
            </div>

            <div class="card" style="margin-bottom: 24px;">
                <div class="card-title">🔌 ПАРАМЕТРИ ПІДКЛЮЧЕННЯ ДЛЯ МАЙНЕРІВ</div>
                <div style="font-size: 13px; color: #c9d1d9; margin-top: 6px;">
                    Майнери можуть підключатися як локально, так і з інших ПК у локальній мережі:
                </div>
                <div class="code-box">HTTP Node RPC:   http://127.0.0.1:8333 або http://192.168.0.100:8333</div>
                <div class="code-box">Stratum Pool:   stratum+tcp://127.0.0.1:3333 або stratum+tcp://192.168.0.100:3333</div>
                <div class="code-box">Запуск майнера:  python start_miner.py 0 (для першої відеокарти RTX 5060 Ti)</div>
            </div>

            <div class="table-card">
                <h3 style="margin-top: 0; margin-bottom: 16px; color: #f0f6fc;">Останні Знайдені Блоки</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Блок</th>
                            <th>Хеш Блоку</th>
                            <th>Складність</th>
                            <th>Nonce</th>
                            <th>Транзакції</th>
                            <th>Винагорода</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows_html}
                    </tbody>
                </table>
            </div>
        </div>
    </body>
    </html>
    """
    return html


@app.get("/api")
def root_api():
    return {
        "network": "Tensorix Mainnet",
        "ticker": "TNX",
        "version": "1.0.0",
        "status": "online"
    }


@app.get("/info")
def get_node_info():
    if not blockchain.chain:
        return {"status": "uninitialized", "blocks": 0}
    
    latest = blockchain.get_latest_block()
    return {
        "network": "Tensorix Network",
        "ticker": "TNX",
        "height": latest.index,
        "latest_block_hash": latest.hash,
        "current_difficulty": latest.difficulty,
        "next_difficulty": blockchain.get_next_difficulty(),
        "mempool_tx_count": len(blockchain.mempool),
        "total_mined_supply_tnx": (sum(b.transactions[0].amount for b in blockchain.chain)) / COIN,
        "peers_count": len(peers)
    }


@app.get("/block/latest")
def get_latest_block():
    if not blockchain.chain:
        raise HTTPException(status_code=404, detail="Blockchain is empty")
    return blockchain.get_latest_block().to_dict()


@app.get("/block/{identifier}")
def get_block(identifier: str):
    if identifier.isdigit():
        idx = int(identifier)
        if 0 <= idx < len(blockchain.chain):
            return blockchain.chain[idx].to_dict()
        raise HTTPException(status_code=404, detail=f"Block index #{idx} not found")
    else:
        for b in blockchain.chain:
            if b.hash == identifier:
                return b.to_dict()
        raise HTTPException(status_code=404, detail=f"Block hash {identifier} not found")


@app.get("/balance/{address}")
def get_balance(address: str):
    balance_units = blockchain.get_balance(address)
    nonce = blockchain.get_account_nonce(address)
    return {
        "address": address,
        "balance_tnx": balance_units / COIN,
        "balance_atomic": balance_units,
        "nonce": nonce
    }


@app.get("/mining/template")
def get_mining_template(address: str = Query(..., description="Miner TNX payout address")):
    if not address.startswith("tnx1"):
        raise HTTPException(status_code=400, detail="Invalid TNX miner address format (must start with tnx1)")
    
    if not blockchain.chain:
        raise HTTPException(status_code=400, detail="Genesis block not yet initialized on node")
    
    template = blockchain.get_block_template(address)
    return template


@app.post("/mining/submit")
def submit_mined_block(req: BlockSubmitRequest):
    block = Block.from_dict(req.model_dump())
    success, msg = blockchain.submit_block(block)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg, "block_hash": block.hash, "index": block.index}


@app.post("/tx/send")
def send_transaction(req: SendTxRequest):
    tx = Transaction(
        sender=req.sender,
        recipient=req.recipient,
        amount=req.amount,
        fee=req.fee,
        nonce=req.nonce,
        public_key=req.public_key,
        signature=req.signature
    )
    success, msg = blockchain.add_transaction(tx)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "txid": tx.txid, "message": msg}


@app.get("/mempool")
def get_mempool():
    return {
        "count": len(blockchain.mempool),
        "transactions": [tx.to_dict() for tx in blockchain.mempool.values()]
    }


@app.get("/p2p/blocks")
def p2p_get_blocks(since: int = 0):
    return [b.to_dict() for b in blockchain.chain[since:since + 100]]


def start_node(host: str = "0.0.0.0", port: int = 8333):
    print(f"Starting Tensorix Node on http://{host}:{port}...")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    start_node()

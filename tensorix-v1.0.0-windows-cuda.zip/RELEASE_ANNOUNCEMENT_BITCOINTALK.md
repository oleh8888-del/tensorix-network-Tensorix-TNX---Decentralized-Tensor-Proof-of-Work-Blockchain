# [ANN] [TNX] Tensorix Network — Decentralized Tensor-Core Proof-of-Work Blockchain

```
  _______ ______ _   _  _____  ____  _____  _______   __
 |__   __|  ____| \ | |/ ____|/ __ \|  __ \|_   _\ \ / /
    | |  | |__  |  \| | (___ | |  | | |__) | | |  \ V / 
    | |  |  __| | . ` |\___ \| |  | |  _  /  | |   > <  
    | |  | |____| |\  |____) | |__| | | \ \ _| |_ / . \ 
    |_|  |______|_| \_|_____/ \____/|_|  \_\_____/_/ \_\
```

**Tensorix (TNX)** is an autonomous Layer-1 cryptocurrency powered by **NVIDIA Tensor Cores**. Mined using matrix-multiplication operations (GEMM) instead of conventional CPU/GPU hashing, Tensorix puts the immense compute capability of consumer AI hardware directly onto the blockchain.

---

### 🌐 Official Network Links (Live Internet Endpoints)
* **Live Block Explorer & Dashboard:** https://279a2fa3af6959.lhr.life/
* **API Documentation:** https://279a2fa3af6959.lhr.life/docs
* **Public Stratum Mining Pool:** `stratum+tcp://wwbre-178-210-130-57.run.pinggy-free.link:39837`
* **Local Stratum Pool (LAN):** `stratum+tcp://192.168.0.100:3333`
* **Algorithm:** TensorHash (INT8 GEMM PoTW)
* **Target Hardware:** NVIDIA RTX 20xx / 30xx / 40xx / 50xx

---

### 💎 Coin Specifications
* **Coin Name:** Tensorix
* **Ticker:** TNX
* **Address Format:** `tnx1...` (Ed25519)
* **Block Time:** 60 seconds
* **Block Reward:** 10 TNX (Halving every 1,051,200 blocks / ~2 years)
* **Max Supply:** 21,000,000 TNX
* **Difficulty Algorithm:** LWMA (Linear Weighted Moving Average, retargeted every block)
* **Genesis Message:** *"Tensorix 2026: Autonomous Tensor-PoW Powered by NVIDIA Tensor Cores"*

---

### 🚀 Quick Start for Miners

#### 1. Requirements
* Windows 10/11 or Linux
* NVIDIA GPU with Tensor Cores (RTX 2060+, 3060+, 4060+, 5060+)
* Python 3.10+ with CUDA support

#### 2. Start Mining
```bash
# Mine via Public Stratum Pool (Worldwide from anywhere)
stratum+tcp://wwbre-178-210-130-57.run.pinggy-free.link:39837
Username: <your_tnx_address>.<worker_name>
Password: x

# Direct Node Mining
python start_miner.py 0 https://279a2fa3af6959.lhr.life
```

#### 3. Wallet Management
```bash
# Check wallet balance
python -m tensorix.wallet.wallet_cli balance

# Transfer coins
python -m tensorix.wallet.wallet_cli send --to tnx1... --amount 10.0
```

---

### 🛡️ Why Tensorix is ASIC-Resistant
TensorHash leverages matrix multiply-accumulate operations that are already optimized at the physical silicon level inside NVIDIA Tensor Cores. Constructing a custom ASIC specifically for dynamic integer GEMM offers zero commercial cost advantage over mass-produced consumer AI GPUs, ensuring decentralized mining distribution for years to come.

"""
Tensorix Network (TNX) - Genesis Block Generator
Generates the cryptographic Genesis Block with initial subsidy and embeds founding message.
"""

import time
import sys

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
from .blockchain.block import Block
from .blockchain.transaction import Transaction, COIN
from .blockchain.chain import Blockchain
from .consensus.tensor_pow import difficulty_to_target, verify_pow

FOUNDER_MESSAGE = "Tensorix 2026: Autonomous Tensor-PoW Powered by NVIDIA Tensor Cores"


def mine_genesis_block(founder_address: str, difficulty: float = 1.0) -> Block:
    """Mine the valid cryptographic Genesis Block for Tensorix."""
    print("=" * 60)
    print("🚀 TENSORIX NETWORK (TNX) - MINING GENESIS BLOCK")
    print("=" * 60)
    print(f"Target Founder Address: {founder_address}")
    print(f"Initial Difficulty:     {difficulty}")
    print(f"Genesis Message:        '{FOUNDER_MESSAGE}'")
    
    now_ts = int(time.time())
    
    # Create Genesis Coinbase Transaction
    coinbase_tx = Transaction(
        sender="COINBASE",
        recipient=founder_address,
        amount=10 * COIN,
        fee=0,
        nonce=0,
        public_key="",
        signature="",
        txid=""
    )
    # Embed founder message in txid computation
    coinbase_tx.signature = FOUNDER_MESSAGE.encode("utf-8").hex()
    coinbase_tx.txid = coinbase_tx.calculate_txid()

    block = Block(
        index=0,
        prev_hash="0" * 64,
        timestamp=now_ts,
        difficulty=difficulty,
        nonce=0,
        transactions=[coinbase_tx]
    )

    header_bytes = block.header_bytes()
    target = difficulty_to_target(difficulty)
    print(f"Header Hash Seed:       {header_bytes.hex()}")
    print(f"Target:                 {hex(target)}")
    print("\nMining Genesis block nonce using Tensor-PoW...")

    start_t = time.time()
    nonce = 0
    while True:
        if verify_pow(header_bytes, nonce, target):
            block.nonce = nonce
            block.hash = block.compute_hash()
            elapsed = time.time() - start_t
            print(f"\n✨ GENESIS BLOCK MINED!")
            print(f"Nonce:       {nonce}")
            print(f"Block Hash:  {block.hash}")
            print(f"Merkle Root: {block.merkle_root}")
            print(f"Time Taken:  {elapsed:.2f}s")
            print("=" * 60)
            return block
        
        nonce += 1
        if nonce % 20 == 0:
            print(f"Testing nonces: {nonce}...", end="\r")


if __name__ == "__main__":
    from .consensus.crypto import generate_keypair
    priv, pub, addr = generate_keypair()
    print(f"Generated Genesis Founder Address: {addr}")
    genesis = mine_genesis_block(addr)

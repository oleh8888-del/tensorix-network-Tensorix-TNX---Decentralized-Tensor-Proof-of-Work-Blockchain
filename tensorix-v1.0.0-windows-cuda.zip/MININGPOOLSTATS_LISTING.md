# MiningPoolStats / Pool Listing Submission — Tensorix (TNX)

### General Information
* **Coin Name:** Tensorix
* **Coin Ticker:** TNX
* **Consensus Type:** Proof-of-Work (PoW)
* **Algorithm:** TensorHash (INT8 GEMM PoTW)
* **Target Hardware:** NVIDIA Tensor Cores (RTX 20xx, 30xx, 40xx, 50xx)
* **Launch Date:** October 2026
* **Premine:** 0% (Fair Launch)
* **Genesis Reward:** 10 TNX (Mined via standard PoW)

### Technical Specifications
* **Block Time:** 60 seconds
* **Block Reward:** 10 TNX
* **Halving Schedule:** Every 1,051,200 blocks
* **Max Supply:** 21,000,000 TNX
* **Difficulty Retargeting:** LWMA (Linear Weighted Moving Average)
* **Address Format:** `tnx1` prefix + 40-character hex (Ed25519)

### Nodes & Mining Endpoints (Public Internet)
* **Official Node RPC:** `https://279a2fa3af6959.lhr.life`
* **Official Stratum Pool:** `stratum+tcp://wwbre-178-210-130-57.run.pinggy-free.link:39837`
* **Block Explorer:** `https://279a2fa3af6959.lhr.life/`
* **Local Fallback (LAN):** `192.168.0.100:3333` / `192.168.0.100:8333`
* **RPC GetBlockTemplate API:** `GET /mining/template?address={payout_address}`
* **RPC SubmitBlock API:** `POST /mining/submit`

### Pool Integration Guide
For pool operators, Tensorix provides standard Stratum V1 over TCP (port 3333) and direct HTTP `getblocktemplate` JSON-RPC APIs compatible with standard open-source mining pool engines (e.g. Yiimp, Miningcore, NOMP).

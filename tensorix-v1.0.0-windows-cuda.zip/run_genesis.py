"""
Tensorix Network (TNX) - Genesis Launcher
Creates founder wallet, mines Genesis Block, and initializes local blockchain database.
"""

import os
import sys

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from tensorix.wallet.wallet_cli import create_wallet, load_wallet, DEFAULT_WALLET_FILE
from tensorix.genesis import mine_genesis_block
from tensorix.blockchain.chain import Blockchain

def main():
    wallet_file = "founder_wallet.json"
    if not os.path.exists(wallet_file):
        print("[Genesis] Creating founder wallet...")
        create_wallet(wallet_file)
    
    wallet = load_wallet(wallet_file)
    founder_addr = wallet["address"]
    print(f"\nFounder Address: {founder_addr}")

    data_dir = "tensorix_data"
    os.makedirs(data_dir, exist_ok=True)
    chain = Blockchain(data_dir=data_dir)

    if chain.chain:
        print(f"⚠️ Blockchain already has {len(chain.chain)} blocks! Genesis block already exists.")
        print(f"Genesis Hash: {chain.chain[0].hash}")
        return

    # Mine Genesis Block with difficulty = 1.0
    genesis_block = mine_genesis_block(founder_addr, difficulty=1.0)
    
    success, msg = chain.submit_block(genesis_block)
    if success:
        print(f"\n✅ SUCCESS! Genesis block written to '{data_dir}/blockchain.json'")
        print(f"Founder Balance: {chain.get_balance(founder_addr) / 100_000_000:.2f} TNX")
    else:
        print(f"\n❌ Error submitting genesis block: {msg}")

if __name__ == "__main__":
    main()
